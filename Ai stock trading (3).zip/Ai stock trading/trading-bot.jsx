import { useState, useEffect, useRef } from "react";

const INITIAL_CASH = 100;

const INITIAL_STATE = {
  cash: INITIAL_CASH,
  portfolio: {},
  trades: [],
  log: [],
  totalValue: INITIAL_CASH,
  peakValue: INITIAL_CASH,
  startTime: Date.now(),
};

function calcTotal(cash, portfolio, prices) {
  let total = cash;
  for (const [sym, { shares }] of Object.entries(portfolio)) {
    if (prices[sym]) total += shares * prices[sym];
  }
  return total;
}

function formatUSD(n) {
  return "$" + n.toFixed(2);
}

function formatPct(n) {
  const sign = n >= 0 ? "+" : "";
  return sign + n.toFixed(2) + "%";
}

function PulsingDot({ color }) {
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
      <span
        style={{
          width: 8,
          height: 8,
          borderRadius: "50%",
          background: color,
          display: "inline-block",
          boxShadow: `0 0 0 0 ${color}`,
          animation: "pulse 1.5s infinite",
        }}
      />
    </span>
  );
}

export default function TradingBot() {
  const [state, setState] = useState(INITIAL_STATE);
  const [prices, setPrices] = useState({});
  const [isRunning, setIsRunning] = useState(false);
  const [isThinking, setIsThinking] = useState(false);
  const [activeTab, setActiveTab] = useState("live");
  const intervalRef = useRef(null);
  const logEndRef = useRef(null);

  useEffect(() => {
    if (logEndRef.current) {
      logEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [state.log]);

  useEffect(() => {
    return () => clearInterval(intervalRef.current);
  }, []);

  async function runTradingCycle(currentState) {
    setIsThinking(true);
    try {
      const portfolioSummary = Object.entries(currentState.portfolio)
        .map(([sym, { shares, avgCost }]) => {
          const currentPrice = prices[sym] || avgCost;
          const value = shares * currentPrice;
          const pnl = (currentPrice - avgCost) * shares;
          return `${sym}: ${shares.toFixed(4)} shares @ avg $${avgCost.toFixed(2)}, current ~$${currentPrice.toFixed(2)}, value $${value.toFixed(2)}, PnL $${pnl.toFixed(2)}`;
        })
        .join("\n") || "Empty - no positions held";

      const recentTrades = currentState.trades
        .slice(-5)
        .map((t) => `${t.action} ${t.symbol} x${t.shares.toFixed(4)} @ $${t.price.toFixed(2)}`)
        .join(", ") || "None";

      const prompt = `You are an aggressive, high-risk AI day trader managing a paper trading portfolio. Your goal is to turn $${INITIAL_CASH} into $1000 as fast as possible.

CURRENT PORTFOLIO STATE:
- Cash available: $${currentState.cash.toFixed(2)}
- Total portfolio value: $${currentState.totalValue.toFixed(2)}
- Gain/Loss: ${formatPct(((currentState.totalValue - INITIAL_CASH) / INITIAL_CASH) * 100)}
- Holdings: ${portfolioSummary}
- Recent trades: ${recentTrades}

YOUR TASK:
1. Use web_search to get REAL current prices for 2-3 high-momentum tickers (from: NVDA, TSLA, AAPL, AMD, META, MSTR, COIN, or top crypto like BTC, ETH, SOL, DOGE).
2. Analyze momentum, news sentiment, and volatility.
3. Make AGGRESSIVE trading decisions — buy the most promising, sell underperformers, concentrate into winners.
4. Respond ONLY in this exact JSON format (no markdown, no extra text):

{
  "prices": {"SYMBOL": price_number, ...},
  "decisions": [
    {"action": "BUY" or "SELL", "symbol": "TICKER", "allocation": 0.0_to_1.0, "reason": "short reason"},
    ...
  ],
  "analysis": "1-2 sentence market read and strategy"
}

Rules:
- allocation for BUY = fraction of available cash to spend (e.g. 0.8 = 80% of cash)
- allocation for SELL = fraction of held shares to sell (e.g. 1.0 = sell all)
- Be BOLD. Concentrate. Don't diversify too much.
- Always search for real prices before deciding.`;

      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          tools: [{ type: "web_search_20250305", name: "web_search" }],
          messages: [{ role: "user", content: prompt }],
        }),
      });

      const data = await response.json();
      const textBlocks = data.content.filter((b) => b.type === "text").map((b) => b.text).join("");

      let parsed;
      try {
        const clean = textBlocks.replace(/```json|```/g, "").trim();
        const jsonMatch = clean.match(/\{[\s\S]*\}/);
        parsed = JSON.parse(jsonMatch[0]);
      } catch {
        setIsThinking(false);
        return currentState;
      }

      const newPrices = { ...prices, ...parsed.prices };
      setPrices(newPrices);

      let newCash = currentState.cash;
      let newPortfolio = { ...currentState.portfolio };
      const newTrades = [...currentState.trades];
      const newLog = [...currentState.log];

      newLog.push({
        time: new Date().toLocaleTimeString(),
        type: "analysis",
        message: parsed.analysis || "Scanning markets...",
      });

      for (const decision of (parsed.decisions || [])) {
        const { action, symbol, allocation, reason } = decision;
        const price = newPrices[symbol];
        if (!price || price <= 0) continue;

        if (action === "BUY" && newCash > 1) {
          const spend = newCash * Math.min(allocation, 1.0);
          if (spend < 0.5) continue;
          const shares = spend / price;
          newCash -= spend;
          const existing = newPortfolio[symbol] || { shares: 0, avgCost: 0 };
          const totalShares = existing.shares + shares;
          const avgCost = (existing.shares * existing.avgCost + spend) / totalShares;
          newPortfolio[symbol] = { shares: totalShares, avgCost };
          newTrades.push({ action: "BUY", symbol, shares, price, time: Date.now() });
          newLog.push({
            time: new Date().toLocaleTimeString(),
            type: "buy",
            message: `BUY ${symbol} — ${shares.toFixed(4)} shares @ $${price.toFixed(2)} | ${reason}`,
          });
        } else if (action === "SELL" && newPortfolio[symbol]) {
          const holding = newPortfolio[symbol];
          const sellShares = holding.shares * Math.min(allocation, 1.0);
          if (sellShares < 0.0001) continue;
          const proceeds = sellShares * price;
          newCash += proceeds;
          const remaining = holding.shares - sellShares;
          if (remaining < 0.0001) {
            delete newPortfolio[symbol];
          } else {
            newPortfolio[symbol] = { ...holding, shares: remaining };
          }
          newTrades.push({ action: "SELL", symbol, shares: sellShares, price, time: Date.now() });
          newLog.push({
            time: new Date().toLocaleTimeString(),
            type: "sell",
            message: `SELL ${symbol} — ${sellShares.toFixed(4)} shares @ $${price.toFixed(2)} | ${reason}`,
          });
        }
      }

      const newTotal = calcTotal(newCash, newPortfolio, newPrices);
      const newState = {
        ...currentState,
        cash: newCash,
        portfolio: newPortfolio,
        trades: newTrades,
        log: newLog,
        totalValue: newTotal,
        peakValue: Math.max(currentState.peakValue, newTotal),
      };
      setState(newState);
      setIsThinking(false);
      return newState;
    } catch (err) {
      setIsThinking(false);
      return currentState;
    }
  }

  function startBot() {
    if (isRunning) return;
    setIsRunning(true);
    let current = state;
    async function cycle() {
      current = await runTradingCycle(current);
    }
    cycle();
    intervalRef.current = setInterval(() => {
      cycle();
    }, 45000);
  }

  function stopBot() {
    setIsRunning(false);
    clearInterval(intervalRef.current);
  }

  function resetBot() {
    stopBot();
    setPrices({});
    setState({ ...INITIAL_STATE, startTime: Date.now() });
  }

  const pnl = state.totalValue - INITIAL_CASH;
  const pnlPct = (pnl / INITIAL_CASH) * 100;
  const isUp = pnl >= 0;
  const progressToGoal = Math.min((state.totalValue / 1000) * 100, 100);

  const accentGreen = "#00ff88";
  const accentRed = "#ff3366";
  const accentBlue = "#00aaff";
  const bg = "#080c10";
  const surface = "#0e1419";
  const border = "#1a2530";

  return (
    <div style={{
      minHeight: "100vh",
      background: bg,
      color: "#e0e8f0",
      fontFamily: "'IBM Plex Mono', 'Courier New', monospace",
      padding: "0",
    }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@300;400;500;600;700&display=swap');
        @keyframes pulse { 0%,100%{box-shadow:0 0 0 0 rgba(0,255,136,0.4)} 50%{box-shadow:0 0 0 8px rgba(0,255,136,0)} }
        @keyframes scanline { 0%{transform:translateY(-100%)} 100%{transform:translateY(100vh)} }
        @keyframes blink { 0%,100%{opacity:1} 50%{opacity:0} }
        @keyframes slideIn { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:translateY(0)} }
        .trade-row { animation: slideIn 0.3s ease; }
        .btn { cursor:pointer; border:none; font-family:inherit; font-size:13px; font-weight:600; letter-spacing:1px; padding:10px 24px; border-radius:2px; transition:all 0.15s; }
        .btn-start { background:${accentGreen}; color:#000; }
        .btn-start:hover { background:#00ffaa; transform:translateY(-1px); }
        .btn-stop { background:${accentRed}; color:#fff; }
        .btn-stop:hover { background:#ff5580; }
        .btn-reset { background:transparent; color:#556; border:1px solid #1a2530; }
        .btn-reset:hover { border-color:#334; color:#99a; }
        .tab { cursor:pointer; padding:8px 16px; font-size:11px; letter-spacing:1px; border-bottom:2px solid transparent; color:#556; transition:all 0.15s; }
        .tab.active { color:${accentBlue}; border-color:${accentBlue}; }
        .tab:hover { color:#aab; }
        ::-webkit-scrollbar{width:4px} ::-webkit-scrollbar-track{background:#0e1419} ::-webkit-scrollbar-thumb{background:#1a2530}
      `}</style>

      {/* Header */}
      <div style={{ background: surface, borderBottom: `1px solid ${border}`, padding: "16px 24px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ fontSize: 18, fontWeight: 700, color: accentGreen, letterSpacing: 2 }}>APEX//TRADER</div>
          <div style={{ fontSize: 10, color: "#334", letterSpacing: 2, marginTop: 2 }}>AI PAPER TRADING SIM</div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          {isRunning && <PulsingDot color={accentGreen} />}
          <span style={{ fontSize: 11, color: isRunning ? accentGreen : "#445", letterSpacing: 1 }}>
            {isThinking ? "ANALYZING..." : isRunning ? "LIVE" : "IDLE"}
          </span>
        </div>
      </div>

      {/* Main grid */}
      <div style={{ padding: "20px 24px", display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 12, maxWidth: 1100, margin: "0 auto" }}>
        {[
          { label: "PORTFOLIO VALUE", value: formatUSD(state.totalValue), sub: formatPct(pnlPct), color: isUp ? accentGreen : accentRed },
          { label: "CASH", value: formatUSD(state.cash), sub: `${((state.cash / state.totalValue) * 100).toFixed(0)}% liquid`, color: accentBlue },
          { label: "TOTAL P&L", value: formatUSD(pnl), sub: `peak ${formatUSD(state.peakValue)}`, color: isUp ? accentGreen : accentRed },
          { label: "TRADES", value: state.trades.length, sub: `${state.trades.filter(t => t.action === "BUY").length}B / ${state.trades.filter(t => t.action === "SELL").length}S`, color: "#aab" },
        ].map((card) => (
          <div key={card.label} style={{ background: surface, border: `1px solid ${border}`, padding: "16px", borderRadius: 2 }}>
            <div style={{ fontSize: 9, color: "#445", letterSpacing: 2, marginBottom: 8 }}>{card.label}</div>
            <div style={{ fontSize: 24, fontWeight: 700, color: card.color }}>{card.value}</div>
            <div style={{ fontSize: 11, color: "#556", marginTop: 4 }}>{card.sub}</div>
          </div>
        ))}
      </div>

      {/* Goal progress */}
      <div style={{ padding: "0 24px 20px", maxWidth: 1100, margin: "0 auto" }}>
        <div style={{ background: surface, border: `1px solid ${border}`, padding: "16px", borderRadius: 2 }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
            <span style={{ fontSize: 10, color: "#445", letterSpacing: 2 }}>MISSION: $100 → $1000</span>
            <span style={{ fontSize: 11, color: accentGreen }}>{progressToGoal.toFixed(1)}% TO GOAL</span>
          </div>
          <div style={{ background: "#0a0f14", height: 6, borderRadius: 1, overflow: "hidden" }}>
            <div style={{
              height: "100%",
              width: `${progressToGoal}%`,
              background: `linear-gradient(90deg, ${accentBlue}, ${accentGreen})`,
              transition: "width 0.5s ease",
              boxShadow: `0 0 10px ${accentGreen}44`,
            }} />
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", marginTop: 6 }}>
            <span style={{ fontSize: 9, color: "#334" }}>$100</span>
            <span style={{ fontSize: 9, color: "#334" }}>$1000</span>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div style={{ padding: "0 24px 20px", maxWidth: 1100, margin: "0 auto", display: "flex", gap: 10 }}>
        {!isRunning
          ? <button className="btn btn-start" onClick={startBot}>▶ START BOT</button>
          : <button className="btn btn-stop" onClick={stopBot}>■ PAUSE</button>
        }
        <button className="btn btn-reset" onClick={resetBot}>↺ RESET</button>
        {isRunning && <span style={{ fontSize: 11, color: "#445", alignSelf: "center", marginLeft: 8 }}>
          Next cycle in ~45s — {isThinking ? "⚡ thinking now..." : "waiting..."}
        </span>}
      </div>

      {/* Tabs */}
      <div style={{ padding: "0 24px", maxWidth: 1100, margin: "0 auto", borderBottom: `1px solid ${border}`, display: "flex", gap: 0 }}>
        {["live", "portfolio", "history"].map(tab => (
          <div key={tab} className={`tab ${activeTab === tab ? "active" : ""}`} onClick={() => setActiveTab(tab)}>
            {tab.toUpperCase()}
          </div>
        ))}
      </div>

      {/* Tab content */}
      <div style={{ padding: "20px 24px", maxWidth: 1100, margin: "0 auto" }}>

        {activeTab === "live" && (
          <div style={{ background: surface, border: `1px solid ${border}`, borderRadius: 2, padding: 16, minHeight: 300, maxHeight: 420, overflowY: "auto" }}>
            {state.log.length === 0
              ? <div style={{ color: "#334", fontSize: 12, textAlign: "center", marginTop: 80 }}>Press START BOT to begin trading simulation</div>
              : state.log.map((entry, i) => (
                <div key={i} className="trade-row" style={{ display: "flex", gap: 12, padding: "6px 0", borderBottom: `1px solid #0e1419`, fontSize: 12 }}>
                  <span style={{ color: "#334", minWidth: 70, flexShrink: 0 }}>{entry.time}</span>
                  <span style={{
                    color: entry.type === "buy" ? accentGreen : entry.type === "sell" ? accentRed : accentBlue,
                    minWidth: 60, flexShrink: 0, fontSize: 10, fontWeight: 600, letterSpacing: 1, alignSelf: "center"
                  }}>
                    {entry.type === "buy" ? "◆ BUY" : entry.type === "sell" ? "◇ SELL" : "● INFO"}
                  </span>
                  <span style={{ color: "#aab", lineHeight: 1.5 }}>{entry.message}</span>
                </div>
              ))
            }
            <div ref={logEndRef} />
          </div>
        )}

        {activeTab === "portfolio" && (
          <div>
            {Object.keys(state.portfolio).length === 0
              ? <div style={{ color: "#334", fontSize: 12, textAlign: "center", marginTop: 80 }}>No open positions</div>
              : Object.entries(state.portfolio).map(([sym, { shares, avgCost }]) => {
                const price = prices[sym] || avgCost;
                const value = shares * price;
                const pnlPos = (price - avgCost) * shares;
                const pnlPctPos = ((price - avgCost) / avgCost) * 100;
                return (
                  <div key={sym} style={{ background: surface, border: `1px solid ${border}`, borderRadius: 2, padding: 16, marginBottom: 8, display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 12 }}>
                    <div>
                      <div style={{ fontSize: 16, fontWeight: 700, color: "#e0e8f0" }}>{sym}</div>
                      <div style={{ fontSize: 10, color: "#445", marginTop: 4 }}>{shares.toFixed(4)} shares</div>
                    </div>
                    <div>
                      <div style={{ fontSize: 10, color: "#445", letterSpacing: 1 }}>CURRENT</div>
                      <div style={{ fontSize: 14, color: "#aab" }}>{formatUSD(price)}</div>
                    </div>
                    <div>
                      <div style={{ fontSize: 10, color: "#445", letterSpacing: 1 }}>VALUE</div>
                      <div style={{ fontSize: 14, color: accentBlue }}>{formatUSD(value)}</div>
                    </div>
                    <div>
                      <div style={{ fontSize: 10, color: "#445", letterSpacing: 1 }}>P&L</div>
                      <div style={{ fontSize: 14, color: pnlPos >= 0 ? accentGreen : accentRed }}>
                        {formatUSD(pnlPos)} ({formatPct(pnlPctPos)})
                      </div>
                    </div>
                  </div>
                );
              })
            }
            <div style={{ background: surface, border: `1px solid ${border}`, borderRadius: 2, padding: 12, marginTop: 8, display: "flex", justifyContent: "space-between" }}>
              <span style={{ fontSize: 11, color: "#445" }}>CASH RESERVE</span>
              <span style={{ fontSize: 14, color: accentBlue, fontWeight: 600 }}>{formatUSD(state.cash)}</span>
            </div>
          </div>
        )}

        {activeTab === "history" && (
          <div style={{ background: surface, border: `1px solid ${border}`, borderRadius: 2, overflow: "hidden" }}>
            <div style={{ display: "grid", gridTemplateColumns: "80px 80px 1fr 100px 100px", gap: 0, padding: "10px 16px", borderBottom: `1px solid ${border}`, fontSize: 9, color: "#445", letterSpacing: 1 }}>
              <span>TIME</span><span>ACTION</span><span>SYMBOL</span><span>SHARES</span><span>PRICE</span>
            </div>
            {state.trades.length === 0
              ? <div style={{ color: "#334", fontSize: 12, textAlign: "center", padding: 60 }}>No trades yet</div>
              : [...state.trades].reverse().map((t, i) => (
                <div key={i} className="trade-row" style={{ display: "grid", gridTemplateColumns: "80px 80px 1fr 100px 100px", gap: 0, padding: "10px 16px", borderBottom: `1px solid #0a0f14`, fontSize: 12 }}>
                  <span style={{ color: "#334", fontSize: 10 }}>{new Date(t.time).toLocaleTimeString()}</span>
                  <span style={{ color: t.action === "BUY" ? accentGreen : accentRed, fontWeight: 600, fontSize: 11 }}>{t.action}</span>
                  <span style={{ color: "#aab" }}>{t.symbol}</span>
                  <span style={{ color: "#778" }}>{t.shares.toFixed(4)}</span>
                  <span style={{ color: "#aab" }}>{formatUSD(t.price)}</span>
                </div>
              ))
            }
          </div>
        )}
      </div>

      <div style={{ textAlign: "center", padding: "20px", fontSize: 9, color: "#223", letterSpacing: 1 }}>
        PAPER TRADING ONLY — NOT REAL MONEY — FOR EDUCATIONAL USE
      </div>
    </div>
  );
}
